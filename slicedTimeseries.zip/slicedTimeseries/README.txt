README

Row codes time series identifier, first column codes start time point, second column codes end time point. NA means until the end of the time series.
