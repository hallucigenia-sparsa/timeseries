README
########

Species are rows and time points are columns.
All time series are scaled such that their minimum sample count is 1000.
Ricker scaling factor: 1000
SOI scaling factor: 50
Hubbell scaling factor: 2

Poisson
=======

Noisy values are generated as: X_ij'=pois(lambda=X_ij) for each species i and time point j

