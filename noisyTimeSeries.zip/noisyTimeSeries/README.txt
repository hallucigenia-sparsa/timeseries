README
########

Species are rows and time points are columns.
All time series are scaled such that their minimum sample count is 1000.
Ricker/gLV scaling factor: 1000
SOI scaling factor: 50
Hubbell scaling factor: 2
DM scaling factor: 1

Identifiers of noisy time series selected for LIMITS:
1,4,5,8,12,13,14,15,16,17,18,19,20,31,32,33,34,35,36,37,38,44,45,46,47,48,49,51,52,53,54,55,56,57,59,60

Poisson
=======

Noisy values are generated as: X_ij'=pois(lambda=X_ij) for each species i and time point j

